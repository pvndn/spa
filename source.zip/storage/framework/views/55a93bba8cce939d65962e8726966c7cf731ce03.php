<?php
$errors = Session::get('errorMessages');
$messages = Session::get('successMessages');
$infos = Session::get('infoMessages');
$warnings = Session::get('warningMessages');
?>
<script type="text/javascript">
    <?php /*Flash message for errors*/ ?>
    <?php if($errors): ?> <?php foreach($errors as $key => $row): ?>
        Utility.showNotification('<?php echo e($row); ?>', 'error');
    <?php endforeach; ?> <?php endif; ?>
    <?php /*Flash message for errors*/ ?>

    <?php /*Flash message for messages*/ ?>
    <?php if($messages): ?> <?php foreach($messages as $key => $row): ?>
        Utility.showNotification('<?php echo e($row); ?>', 'success');
    <?php endforeach; ?> <?php endif; ?>
    <?php /*Flash message for messages*/ ?>

    <?php /*Flash message for infors*/ ?>
    <?php if($infos): ?> <?php foreach($infos as $key => $row): ?>
        Utility.showNotification('<?php echo e($row); ?>', 'info');
    <?php endforeach; ?> <?php endif; ?>
    <?php /*Flash message for infors*/ ?>

    <?php /*Flash message for warnings*/ ?>
    <?php if($warnings): ?> <?php foreach($warnings as $key => $row): ?>
        Utility.showNotification('<?php echo e($row); ?>', 'warning');
    <?php endforeach; ?> <?php endif; ?>
    <?php /*/=Flash message for warnings*/ ?>
</script>
