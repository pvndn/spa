
<!DOCTYPE html>
<!--[if IE 8]>
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="ie8 no-js <?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>"> <![endif]-->
<!--[if IE 9]>
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="ie9 no-js <?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo e(isset($currentLanguageCode) ? $currentLanguageCode : 'en'); ?>" class="<?php echo e(($showHeaderAdminBar) ? 'show-admin-bar' : ''); ?>">
<!--<![endif]-->
<head>
    <?php echo $__env->make('front/_shared/_metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- GLOBAL PLUGINS -->
    <?php /*<link rel="stylesheet" href="/fonts/Open-Sans/font.css">*/ ?>
    <!-- GLOBAL PLUGINS -->

    <!-- OTHER PLUGINS -->
    <?php echo $__env->yieldContent('css'); ?>
    <!-- END OTHER PLUGINS -->

    <!-- BEGIN THEME LAYOUT STYLES -->
    <link href="/css/style.css" rel="stylesheet" type="text/css"/>
    <!-- END THEME LAYOUT STYLES -->

    <?php if($showHeaderAdminBar): ?>
        <link rel="stylesheet" href="/admin/css/admin-bar.css">
    <?php endif; ?>

    <link rel="shortcut icon" href="/images/logo/favicon.png"/>

    <?php echo isset($CMSSettings['google_analytics']) ? $CMSSettings['google_analytics'] : ''; ?>

</head>

<body class="on-loading <?php echo e(isset($bodyClass) ? $bodyClass : ''); ?>">

<?php if($showHeaderAdminBar): ?>
    <?php echo $__env->make('admin/_shared/_admin-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<div class="site-wrapper">
    <header class="header">
        <?php echo $__env->make('front/_shared/_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>

    <main class="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="footer">
        <?php echo $__env->make('front/_shared/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>
</div>

<!--Modals-->
<?php echo $__env->make('front/_shared/_modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!--Google captcha-->
<?php echo $__env->make('front/_shared/_google-captcha', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Google captcha-->

<!-- BEGIN CORE PLUGINS -->
<script src="/dist/core.min.js"></script>
<!-- END CORE PLUGINS -->

<!-- OTHER PLUGINS -->
<?php echo $__env->yieldContent('js'); ?>
<!-- END OTHER PLUGINS -->

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="/dist/app.min.js"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<!-- JS INIT -->
<?php echo $__env->yieldContent('js-init'); ?>
<!-- JS INIT -->

<?php echo $__env->make('front/_shared/_flash-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>