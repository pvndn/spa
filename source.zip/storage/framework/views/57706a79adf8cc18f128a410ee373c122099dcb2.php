<!-- BEGIN SIDEBAR -->
<?php echo isset($CMSMenuHtml) ? $CMSMenuHtml : ''; ?>

<!-- END SIDEBAR -->
