<?php $__env->startSection('page-toolbar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script type="text/javascript">
        $(document).ready(function(){

        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="portlet light form-fit bordered">
        <?php if(isset($object) && !$object->parent_id): ?>
            <div class="portlet-title">
                <div class="actions btn-set">
                    <a type="button" href="/<?php echo e($adminCpAccess); ?>/comments/reply/<?php echo e($object->id); ?>" class="btn btn-secondary-outline default">
                        <i class="fa fa-reply"></i> Reply
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="portlet-title">
                <div class="caption">
                    Comment reply for <a href="/<?php echo e($adminCpAccess); ?>/comments/edit/<?php echo e($object->parent_id); ?>">#<?php echo e($object->parent_id); ?></a>
                </div>
            </div>
        <?php endif; ?>
        <div class="portlet-body form">
            <!-- BEGIN FORM-->
            <form class="form-horizontal form-bordered" action="" method="POST" accept-charset="UTF-8">
                <?php echo csrf_field(); ?>

                <div class="form-body">
                    <div class="form-group">
                        <div class="col-md-3 text-right">Title</div>
                        <div class="col-md-7">
                            <input class="form-control" type="text" name="title" value="<?php echo e(isset($object->title) ? $object->title : ''); ?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 text-right">Name</div>
                        <div class="col-md-7">
                            <input class="form-control" type="text" name="name" value="<?php echo e(isset($object->name) ? $object->name : ''); ?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 text-right">Phone</div>
                        <div class="col-md-7">
                            <input class="form-control" type="text" name="phone" value="<?php echo e(isset($object->phone) ? $object->phone : ''); ?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 text-right">Email</div>
                        <div class="col-md-7">
                            <input class="form-control" type="text" name="email" value="<?php echo e(isset($object->email) ? $object->email : ''); ?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 text-right">Status</div>
                        <div class="col-md-7">
                            <select name="status" class="form-control">
                                <option value="0" <?php echo e($object->status != 1 ? 'selected=selected' : ''); ?>>Pending</option>
                                <option value="1" <?php echo e($object->status == 1 ? 'selected=selected' : ''); ?>>Allowed</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 text-right">Content</div>
                        <div class="col-md-7">
                            <textarea name="content" rows="5" class="form-control"><?php echo isset($object->content) ? $object->content : ''; ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-push-3 col-md-7 text-right">
                            <button type="submit" class="btn btn-circle green font-white btn-default">
                                <i class="fa fa-check"></i> Update
                            </button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- END FORM-->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>