<?php $__env->startSection('page-toolbar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- BEGIN DASHBOARD STATS -->
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="dashboard-stat red-intense">
            <div class="visual">
                <i class="fa fa-tasks"></i>
            </div>
            <div class="details">
                <div class="number">
                    <?php echo e($pagesCount); ?>

                </div>
                <div class="desc">
                    Total pages
                </div>
            </div>
            <a class="more" href="<?php echo e('/'.$adminCpAccess.'/pages'); ?>">
                Explore <i class="m-icon-swapright m-icon-white"></i>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="dashboard-stat yellow">
            <div class="visual">
                <i class="icon-layers"></i>
            </div>
            <div class="details">
                <div class="number">
                    <?php echo e($postsCount); ?>

                </div>
                <div class="desc">
                    Total posts
                </div>
            </div>
            <a class="more" href="<?php echo e('/'.$adminCpAccess.'/posts'); ?>">
                Explore <i class="m-icon-swapright m-icon-white"></i>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="dashboard-stat yellow-gold">
            <div class="visual">
                <i class="fa fa-cubes"></i>
            </div>
            <div class="details">
                <div class="number">
                    <?php echo e($productsCount); ?>

                </div>
                <div class="desc">
                    Total products
                </div>
            </div>
            <a class="more" href="<?php echo e('/'.$adminCpAccess.'/products'); ?>">
                Explore <i class="m-icon-swapright m-icon-white"></i>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="dashboard-stat green-sharp">
            <div class="visual">
                <i class="fa fa-cubes"></i>
            </div>
            <div class="details">
                <div class="number">
                    <?php echo e($usersCount); ?>

                </div>
                <div class="desc">
                    Total activated users
                </div>
            </div>
            <a class="more" href="<?php echo e('/'.$adminCpAccess.'/users'); ?>">
                Explore <i class="m-icon-swapright m-icon-white"></i>
            </a>
        </div>
    </div>
</div>
<!-- END DASHBOARD STATS -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>