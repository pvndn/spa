<div class="page-footer-inner"> 2015 &copy; LaraWebEd. All rights reserved.</div>
<div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
</div>
