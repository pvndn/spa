<div class="line" data-option="buttonlabel">
    <div class="col-xs-3">
        <h5>Button label</h5>
    </div>
    <div class="col-xs-9">
        <h5>Button label</h5>
        <input type="text" class="form-control" placeholder="" value="{{ $options->buttonlabel or '' }}">
    </div>
    <div class="clearfix"></div>
</div>