<div class="container">
    <div class="row">
        <div class="text-center col-lg-12">
            <p>LaraWebEd &copy; 2015 - 2016. All rights reserved.</p>
        </div>
    </div>
</div>