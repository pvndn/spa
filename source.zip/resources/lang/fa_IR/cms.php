<?php
return [
    'requestCompleted' => 'درخواست تکمیل شده است',
    'requestNotCompleted' => 'درخواست تکمیل نشده است',
    'page' => 'صفحه',
];
