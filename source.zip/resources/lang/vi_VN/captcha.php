<?php

return [
    'error' => 'Sai mã captcha',
];