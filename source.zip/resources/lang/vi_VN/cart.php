<?php
return [
    'addCartError' => 'Có lỗi xảy ra trong quá trình thêm giỏ hàng',
    'maxQuantityError' => 'Số lượng sản phẩm trong giỏ hàng đã đạt đến giới hạn',
    'productNotExistsInCart' => 'Sản phẩm không tồn tại trong giỏ hàng',
    'updateCartCompleted' => 'Thêm sản phẩm vào giỏ hàng thành công',
];