<?php

return [
    'post' => 'post',
    'category' => 'category',
    'product' => 'product',
    'productCategory' => 'product-category',
];